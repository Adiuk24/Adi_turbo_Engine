AdiTurbo CLI Package

Install:
  1) Copy this folder wherever you want
  2) Add "<package>/bin" to PATH
  3) Run: aditurbo help

Included binaries:
  llama-cli, llama-quantize, llama-bench, llama-perplexity, llama-imatrix

Runtime default:
  aditurbo run --model <model.gguf>
